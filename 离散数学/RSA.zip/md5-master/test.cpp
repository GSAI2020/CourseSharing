#include "md5.h"

int main(){
    char cstring[] = "Foo baz, testing.";

    printf("md5sum6: %s\n", md5sum6( cstring ).c_str());
    return 0;
}