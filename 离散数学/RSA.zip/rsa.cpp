//Author: 林宁 2020201612 
//为了压缩时间，很多算法是参考网上的，我做了一个整合，主要的参考网站如下：
//1. Miller-Robin素性判定：https://zhuanlan.zhihu.com/p/349360074
//2. 快速乘：https://www.cnblogs.com/812-xiao-wen/p/10543023.html
//3. 线性同余法的参数选取：https://en.wikipedia.org/wiki/Linear_congruential_generator#Parameters_in_common_use
//4. 公钥、私钥与签名相关概念：https://zhuanlan.zhihu.com/p/158719271
//5. MD5的c++实现：https://github.com/ulwanski/md5

#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <string.h>
#include <string>
#include <cstring>
#define max(x, y) (x > y ? x: y)


#define CLEARTXT_STEP 7 // 表明在明文中以7字节为单位（为了防止溢出，不要等于或超过8字节），不要太小，否则容易通过词频获取映射关系
#define CIPHERTXT_STEP 8 // 表明在密文中以8字节为单位，防止发生截取造成使加密信息错误
#define PRIME_BITS 30 // 选择质数的位数，该选择为防止选择的n过小使加密信息错误，选择的n过大使长长整型溢出
#define MAX_STR_LEN 0xffff //字符串最大长度
#define MAX_ITER 0xffff // 随机化选取质数的最大迭代轮数
typedef long long ll;
typedef unsigned long long ull;

ull seed = time(NULL);//将种子置为当前系统时间

ll extend_gcd(ll a, ll b, ll& x, ll& y);
inline ull rand64();
inline ll randint(ll min, ll max);
inline ll qmul(ll a, ll b, ll mod);
ll qpow(ll a, ll n, ll mod);
char MRtest(ll n);
int randprime(ll min, ll max);
void padding(char*& str, int& length, int step);
void encipher(char*& clear, int& length, ll mod, ll key, int s_step, int d_step);
void getKey(ll& mod, ll& e, ll& d);
std::string md5(const void* dat, size_t len);

//拓展欧几里得算法求逆
ll extend_gcd(ll a, ll b, ll& x, ll& y){
    if(b == 0){
        x = 1, y = 0;
        return a;
    }
    else{
        ll r = extend_gcd(b, a % b, y, x);
        y -= a / b * x;
        return r;
    }
}

inline ull rand64(){//线性同余法，该系数由Donald Knuth给出
    return seed = 6364136223846793005 * seed + 1442695040888963407;//自动模2^64
}

//请确保max-min为正且远小于unsigned long long最大范围（2^64），否则生成的随机数是不够均匀的
inline ll randint(ll min, ll max){
    //该函数返回[min, max)范围的随机数
    return min + rand64() % (max - min);
}

//模拟二进制乘法并求模
inline ll qmul(ll a, ll b, ll mod){
    ll res = 0;
    while(b){
        if(b & 1) res = (res + a) % mod;
        a = (a << 1) % mod;
        b >>= 1;
    }
    return res;
}

//快速幂
ll qpow(ll a, ll n, ll mod){
    ll res = 1;
    while(n)
    {
        if(n & 1) res = qmul(res, a, mod);
        a = qmul(a, a, mod);
        n >>= 1;
    }
    return res;
}

//Miller-Rabbin素性检验，一般情况下判断失误的错误率极小，这里针对长长整型选取的数一定不会导致判断错误
char MRtest(ll n){
    if(n < 3 || !(n & 1)) return n == 2;//特判
    ll u = n - 1, t = 0;
    while(!(u & 1)) u >>= 1, ++t;
    ll ud[] = {2, 325, 9375, 28178, 450775, 9780504, 1795265022};//该选择不会导致长长整型范围内的判断错误
    for(ll a:ud)
    {
        ll v = qpow(a, u, n);
        if(v == 1 || v == n - 1 || v == 0) continue;
        for(int j = 1; j <= t; j++)
        {
            v = qmul(v, v, n);
            if(v == n - 1 && j != t){v = 1; break;}//出现一个n-1，后面都是1，直接跳出
            if(v == 1) return 0;//这里代表前面没有出现n-1这个解，二次检验失败
        }
        if(v != 1) return 0;//Fermat检验
    }
    return 1;
}

//生成指定范围的随机质数
int randprime(ll min, ll max){
    int p, count = 0;
    while(!MRtest(p = randint(min, max)) && ++count < MAX_ITER){}
	if(count >= MAX_ITER) exit(-1);
    return p;
}

void padding(char*& str, int& length, int step){
    int new_len = (length / step) * step;
    if(new_len < length) length = new_len + step;
    else length = new_len;
    char* pad_str = (char *)calloc(length + 1, sizeof(char));
    strcpy(pad_str, str);
    free(str);
    str = pad_str;
}

//对信息进行加密与解码，两个过程是互逆的
void encipher(char*& clear, int& length, ll mod, ll key, int s_step, int d_step){
    int steps = length / s_step;
    length = steps * d_step;
    char* cipher = (char *)calloc(length + 1, sizeof(char));//用calloc保证密文的初始化
    for(int i = 0; i < steps; i++){
        ll base = 0;
        memcpy(&base, clear + i * s_step, s_step);//内存复制操作，即这里编码默认使用的是ascii
        printf("%llx->", base);
        base = qpow(base, key, mod);//幂运算取模
        printf("%llx\n", base);
        memcpy(cipher + i * d_step, &base, d_step);
    }
    printf("\n");
    free(clear);
    clear = cipher;
}

void getKey(ll& mod, ll& e, ll& d){ 
    ll p1 = randprime(1 << (PRIME_BITS - 1), 1 << PRIME_BITS);
    ll p2 = randprime(1 << (PRIME_BITS - 1), 1 << PRIME_BITS); 
    ll phi = (p1 - 1) * (p2 - 1); // 大质数乘积的欧拉函数phi
    mod = p1 * p2; // 大质数
    e = randprime(max(p1, p2) + 1, phi); // 获取与p1、p2和phi互质的e
    ll _;
    ll r = extend_gcd(e, phi, d, _); // 获取e模phi的逆d
    d = (d + phi) % phi; // 将d强制转为正整数，否则在求幂的过程会出错. 这里加法不会溢出，因为d会小于phi，而phi不会超过62位  
}


//这个算法完全照搬https://github.com/ulwanski/md5，将任意长度的字符串转为定长的md5码，这里是16位的
#ifndef HAVE_OPENSSL

	#define F(x, y, z)   ((z) ^ ((x) & ((y) ^ (z))))
	#define G(x, y, z)   ((y) ^ ((z) & ((x) ^ (y))))
	#define H(x, y, z)   ((x) ^ (y) ^ (z))
	#define I(x, y, z)   ((y) ^ ((x) | ~(z)))
	#define STEP(f, a, b, c, d, x, t, s) \
		(a) += f((b), (c), (d)) + (x) + (t); \
		(a) = (((a) << (s)) | (((a) & 0xffffffff) >> (32 - (s)))); \
		(a) += (b);

	#if defined(__i386__) || defined(__x86_64__) || defined(__vax__)
		#define SET(n) \
			(*(MD5_u32 *)&ptr[(n) * 4])
		#define GET(n) \
			SET(n)
	#else
		#define SET(n) \
			(ctx->block[(n)] = \
			(MD5_u32)ptr[(n) * 4] | \
			((MD5_u32)ptr[(n) * 4 + 1] << 8) | \
			((MD5_u32)ptr[(n) * 4 + 2] << 16) | \
			((MD5_u32)ptr[(n) * 4 + 3] << 24))
		#define GET(n) \
			(ctx->block[(n)])
	#endif

	typedef unsigned int MD5_u32;

	typedef struct {
		MD5_u32 lo, hi;
		MD5_u32 a, b, c, d;
		unsigned char buffer[64];
		MD5_u32 block[16];
	} MD5_CTX;
 
	static void MD5_Init(MD5_CTX *ctx);
	static void MD5_Update(MD5_CTX *ctx, const void *data, unsigned long size);
	static void MD5_Final(unsigned char *result, MD5_CTX *ctx);

	static const void *body(MD5_CTX *ctx, const void *data, unsigned long size){
		const unsigned char *ptr;
		MD5_u32 a, b, c, d;
		MD5_u32 saved_a, saved_b, saved_c, saved_d;
 
		ptr = (const unsigned char*)data;
 
		a = ctx->a;
		b = ctx->b;
		c = ctx->c;
		d = ctx->d;
 
		do {
			saved_a = a;
			saved_b = b;
			saved_c = c;
			saved_d = d;

			STEP(F, a, b, c, d, SET(0), 0xd76aa478, 7)
			STEP(F, d, a, b, c, SET(1), 0xe8c7b756, 12)
			STEP(F, c, d, a, b, SET(2), 0x242070db, 17)
			STEP(F, b, c, d, a, SET(3), 0xc1bdceee, 22)
			STEP(F, a, b, c, d, SET(4), 0xf57c0faf, 7)
			STEP(F, d, a, b, c, SET(5), 0x4787c62a, 12)
			STEP(F, c, d, a, b, SET(6), 0xa8304613, 17)
			STEP(F, b, c, d, a, SET(7), 0xfd469501, 22)
			STEP(F, a, b, c, d, SET(8), 0x698098d8, 7)
			STEP(F, d, a, b, c, SET(9), 0x8b44f7af, 12)
			STEP(F, c, d, a, b, SET(10), 0xffff5bb1, 17)
			STEP(F, b, c, d, a, SET(11), 0x895cd7be, 22)
			STEP(F, a, b, c, d, SET(12), 0x6b901122, 7)
			STEP(F, d, a, b, c, SET(13), 0xfd987193, 12)
			STEP(F, c, d, a, b, SET(14), 0xa679438e, 17)
			STEP(F, b, c, d, a, SET(15), 0x49b40821, 22)
			STEP(G, a, b, c, d, GET(1), 0xf61e2562, 5)
			STEP(G, d, a, b, c, GET(6), 0xc040b340, 9)
			STEP(G, c, d, a, b, GET(11), 0x265e5a51, 14)
			STEP(G, b, c, d, a, GET(0), 0xe9b6c7aa, 20)
			STEP(G, a, b, c, d, GET(5), 0xd62f105d, 5)
			STEP(G, d, a, b, c, GET(10), 0x02441453, 9)
			STEP(G, c, d, a, b, GET(15), 0xd8a1e681, 14)
			STEP(G, b, c, d, a, GET(4), 0xe7d3fbc8, 20)
			STEP(G, a, b, c, d, GET(9), 0x21e1cde6, 5)
			STEP(G, d, a, b, c, GET(14), 0xc33707d6, 9)
			STEP(G, c, d, a, b, GET(3), 0xf4d50d87, 14)
			STEP(G, b, c, d, a, GET(8), 0x455a14ed, 20)
			STEP(G, a, b, c, d, GET(13), 0xa9e3e905, 5)
			STEP(G, d, a, b, c, GET(2), 0xfcefa3f8, 9)
			STEP(G, c, d, a, b, GET(7), 0x676f02d9, 14)
			STEP(G, b, c, d, a, GET(12), 0x8d2a4c8a, 20)
			STEP(H, a, b, c, d, GET(5), 0xfffa3942, 4)
			STEP(H, d, a, b, c, GET(8), 0x8771f681, 11)
			STEP(H, c, d, a, b, GET(11), 0x6d9d6122, 16)
			STEP(H, b, c, d, a, GET(14), 0xfde5380c, 23)
			STEP(H, a, b, c, d, GET(1), 0xa4beea44, 4)
			STEP(H, d, a, b, c, GET(4), 0x4bdecfa9, 11)
			STEP(H, c, d, a, b, GET(7), 0xf6bb4b60, 16)
			STEP(H, b, c, d, a, GET(10), 0xbebfbc70, 23)
			STEP(H, a, b, c, d, GET(13), 0x289b7ec6, 4)
			STEP(H, d, a, b, c, GET(0), 0xeaa127fa, 11)
			STEP(H, c, d, a, b, GET(3), 0xd4ef3085, 16)
			STEP(H, b, c, d, a, GET(6), 0x04881d05, 23)
			STEP(H, a, b, c, d, GET(9), 0xd9d4d039, 4)
			STEP(H, d, a, b, c, GET(12), 0xe6db99e5, 11)
			STEP(H, c, d, a, b, GET(15), 0x1fa27cf8, 16)
			STEP(H, b, c, d, a, GET(2), 0xc4ac5665, 23)
			STEP(I, a, b, c, d, GET(0), 0xf4292244, 6)
			STEP(I, d, a, b, c, GET(7), 0x432aff97, 10)
			STEP(I, c, d, a, b, GET(14), 0xab9423a7, 15)
			STEP(I, b, c, d, a, GET(5), 0xfc93a039, 21)
			STEP(I, a, b, c, d, GET(12), 0x655b59c3, 6)
			STEP(I, d, a, b, c, GET(3), 0x8f0ccc92, 10)
			STEP(I, c, d, a, b, GET(10), 0xffeff47d, 15)
			STEP(I, b, c, d, a, GET(1), 0x85845dd1, 21)
			STEP(I, a, b, c, d, GET(8), 0x6fa87e4f, 6)
			STEP(I, d, a, b, c, GET(15), 0xfe2ce6e0, 10)
			STEP(I, c, d, a, b, GET(6), 0xa3014314, 15)
			STEP(I, b, c, d, a, GET(13), 0x4e0811a1, 21)
			STEP(I, a, b, c, d, GET(4), 0xf7537e82, 6)
			STEP(I, d, a, b, c, GET(11), 0xbd3af235, 10)
			STEP(I, c, d, a, b, GET(2), 0x2ad7d2bb, 15)
			STEP(I, b, c, d, a, GET(9), 0xeb86d391, 21)
 
			a += saved_a;
			b += saved_b;
			c += saved_c;
			d += saved_d;
 
			ptr += 64;
		} while (size -= 64);
 
		ctx->a = a;
		ctx->b = b;
		ctx->c = c;
		ctx->d = d;
 
		return ptr;
	}
 
	void MD5_Init(MD5_CTX *ctx){
		ctx->a = 0x67452301;
		ctx->b = 0xefcdab89;
		ctx->c = 0x98badcfe;
		ctx->d = 0x10325476;
 
		ctx->lo = 0;
		ctx->hi = 0;
	}
 
	void MD5_Update(MD5_CTX *ctx, const void *data, unsigned long size){
		MD5_u32 saved_lo;
		unsigned long used, free;
 
		saved_lo = ctx->lo;
		if ((ctx->lo = (saved_lo + size) & 0x1fffffff) < saved_lo)
			ctx->hi++;
		ctx->hi += size >> 29;
		used = saved_lo & 0x3f;
 
		if (used){
			free = 64 - used;
			if (size < free) {
				memcpy(&ctx->buffer[used], data, size);
				return;
			}
 
			memcpy(&ctx->buffer[used], data, free);
			data = (unsigned char *)data + free;
			size -= free;
			body(ctx, ctx->buffer, 64);
		}
 
		if (size >= 64) {
			data = body(ctx, data, size & ~(unsigned long)0x3f);
			size &= 0x3f;
		}
 
		memcpy(ctx->buffer, data, size);
	}
 
	void MD5_Final(unsigned char *result, MD5_CTX *ctx){
		unsigned long used, free;
		used = ctx->lo & 0x3f;
		ctx->buffer[used++] = 0x80;
		free = 64 - used;
 
		if (free < 8) {
			memset(&ctx->buffer[used], 0, free);
			body(ctx, ctx->buffer, 64);
			used = 0;
			free = 64;
		}
 
		memset(&ctx->buffer[used], 0, free - 8);
 
		ctx->lo <<= 3;
		ctx->buffer[56] = ctx->lo;
		ctx->buffer[57] = ctx->lo >> 8;
		ctx->buffer[58] = ctx->lo >> 16;
		ctx->buffer[59] = ctx->lo >> 24;
		ctx->buffer[60] = ctx->hi;
		ctx->buffer[61] = ctx->hi >> 8;
		ctx->buffer[62] = ctx->hi >> 16;
		ctx->buffer[63] = ctx->hi >> 24;
		body(ctx, ctx->buffer, 64);
		result[0] = ctx->a;
		result[1] = ctx->a >> 8;
		result[2] = ctx->a >> 16;
		result[3] = ctx->a >> 24;
		result[4] = ctx->b;
		result[5] = ctx->b >> 8;
		result[6] = ctx->b >> 16;
		result[7] = ctx->b >> 24;
		result[8] = ctx->c;
		result[9] = ctx->c >> 8;
		result[10] = ctx->c >> 16;
		result[11] = ctx->c >> 24;
		result[12] = ctx->d;
		result[13] = ctx->d >> 8;
		result[14] = ctx->d >> 16;
		result[15] = ctx->d >> 24;
		memset(ctx, 0, sizeof(*ctx));
	}
#else
	#include <openssl/md5.h>
#endif

using namespace std;

/* Return Calculated raw result(always little-endian), the size is always 16 */
void md5bin(const void* dat, size_t len, unsigned char out[16]) {
    MD5_CTX c;
    MD5_Init(&c);
    MD5_Update(&c, dat, len);
    MD5_Final(out, &c);
}

static char hb2hex(unsigned char hb) {
    hb = hb & 0xF;
    return hb < 10 ? '0' + hb : hb - 10 + 'a';
}

/* Generate shorter md5sum by something like base62 instead of base16 or base10. 0~61 are represented by 0-9a-zA-Z */
string md5(const void* dat, size_t len){
    string res;
    unsigned char out[16];
    md5bin(dat, len, out);
    for(size_t i = 0; i < 16; ++ i) {
        res.push_back(hb2hex(out[i] >> 4));
        res.push_back(hb2hex(out[i]));
    }
    return res;
}

int main(){
    ll mod, e, d;
    getKey(mod, e, d);
    printf("public key:\nn=%lld, e=%lld\n\n", mod, e);
    printf("pravate key:\nn=%lld, d=%lld\n\n", mod, d);//获取公钥与私钥
	
	//假设Bob公钥为(n,e)，私钥为(n,d)
	
	//模拟Alice向Bob发送密文，Bob解密密文的过程，这里省去认证过程
    char* clear = (char *)calloc(MAX_STR_LEN + 1, sizeof(char));
    //strcpy(clear, "linning2020201612");
	strcpy(clear, "RSA: To decrypt a RSA ciphertext message, "
	"the decryption key d, an inverse of e modulo (p-1)(q-1) is needed. "
	"The inverse exists since gcd(e,(p-1)(q-1)) = gcd(13, 42*58) = 1.\n"
	"With the decryption key d, we can decrypt each block  with the computation M = Cd mod p*q."
	" (see text for full derivation)\n"
	"RSA works as a public key system since the only known method of finding d is based on "
	"a factorization of n into primes. "
	"There is currently no known feasible method for factoring large numbers into primes.\n"
	"--Copy from ppt of Teacher He."
	);//明文
	
	int l_c = strlen(clear);  
    padding(clear, l_c, CLEARTXT_STEP);//对齐操作，方便对信息分组加密
	printf("cleartext:\n%s\n\n", clear);
    printf("encipher cleartext:\n");
    encipher(clear, l_c, mod, e, CLEARTXT_STEP, CIPHERTXT_STEP);//Alice用Bob的公钥加密明文
    printf("decipher to cleartext:\n");
    encipher(clear, l_c, mod, d, CIPHERTXT_STEP, CLEARTXT_STEP);//Bob用自己的私钥解密密文
    printf("deciphered ciphertext:\n%s\n\n", clear);
    

	//模拟Bob签名，Alice从Bob中获取带签名的数据并进行验证的过程
    char* digest = (char *)calloc(MAX_STR_LEN + 1, sizeof(char));
	string digest_str = md5(clear, strlen(clear)).c_str();
	strcpy(digest, digest_str.c_str());//利用md5（一种加密哈希算法）获取数据摘要
	int l_d = strlen(digest);
	padding(digest, l_d, CLEARTXT_STEP);//对齐操作，方便对信息分组加密
	printf("digest:\n%s\n\n", digest);
	
	printf("encipher digest:\n");
    encipher(digest, l_d, mod, d, CLEARTXT_STEP, CIPHERTXT_STEP);//Bob用自己的私钥签名，加密数据摘要
    printf("decipher to digest:\n");
    encipher(digest, l_d, mod, e, CIPHERTXT_STEP, CLEARTXT_STEP);//Alice用Bob的公钥解密签名，得到数据摘要
    printf("deciphered signature:\n%s\n\n", digest);
	printf("Is valid:\n%d\n\n", strcmp(digest, digest_str.c_str()) == 0);//Alice用得到的数据生成的摘要与签名解密出的摘要进行比对

	char* fake_clear = (char *)calloc(MAX_STR_LEN + 1, sizeof(char));
    //strcpy(fake_clear, "linning2020201613");
	strcpy(fake_clear, "RSA: To decrypt a RSA ciphertext message, "
	"the decryption key d, an inverse of e modulo (p-1)(q-1) is needed. "
	"The inverse exists since gcd(e,(p-1)(q-1)) = gcd(13, 42*58) = 1.\n"
	"With the decryption key d, we can decrypt each block  with the computation M = Cd mod p*q."
	" (see text for full derivation)\n"
	"RSA works as a public key system since the only known method of finding d is based on "
	"a factorization of n into primes. "
	"There is currently no known feasible method for factoring large numbers into primes.\n"
	"--Copy from ppt of Teacher He,"
	);//仅仅修改末尾的一个符号，得到的md5的值极大可能完全不同！
	string fake_digest_str = md5(fake_clear, strlen(fake_clear));
	printf("fake deciphered signature:\n%s\n\n", fake_digest_str.c_str());
	printf("Is valid:\n%d\n\n", strcmp(digest, fake_digest_str.c_str()) == 0);//这表明数据中途被修改了

    return 0;
}